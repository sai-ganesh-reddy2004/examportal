package com.OnlineExamPortal.UserModule.Model;

public enum Role {
	ADMIN,STUDENT,EXAMINER;
}


